package main

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/east-true/my-agent-tools/internal/cli"
	"github.com/east-true/my-agent-tools/internal/command"
	"github.com/east-true/my-agent-tools/internal/github"
	sdk "github.com/google/go-github/v92/github"
	"os"
	"time"
)

func execute() int {
	ctx := context.Background()
	if len(os.Args) > 1 && os.Args[1] == "fs" {
		return cli.Run(ctx, os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
	}
	for _, arg := range os.Args[1:] {
		if arg == "--read-evidence" {
			return cli.Run(ctx, os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
		}
	}
	api, err := github.NewAPI(ctx, command.Exec{})
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	concrete := api.(github.SDK)
	base := os.Getenv("BRANCH_BENCHMARK_URL") + "/"
	concrete.Client, err = concrete.Client.Clone(sdk.WithURLs(&base, nil))
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return cli.RunBranchBenchmark(ctx, os.Args[1:], os.Stdin, os.Stdout, os.Stderr, concrete)
}
func main() {
	started := time.Now()
	code := execute()
	if p := os.Getenv("USAGE_BENCHMARK_CLI_LOG"); p != "" {
		if f, err := os.OpenFile(p, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600); err == nil {
			json.NewEncoder(f).Encode(map[string]any{"args": os.Args[1:], "exit_code": code, "seconds": time.Since(started).Seconds()})
			f.Close()
		}
	}
	os.Exit(code)
}
