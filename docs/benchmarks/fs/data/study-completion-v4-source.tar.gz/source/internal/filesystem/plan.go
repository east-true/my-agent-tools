package filesystem

import (
	"context"
	"errors"
	"fmt"
	"strings"
)

// CountTarget explicitly authorizes recounting one replacement in the input spec.
// Both positions are 1-based; all other counts remain strict.
type CountTarget struct {
	File        int
	Replacement int
}

// GeneratePlan captures exact original-byte hashes without asking the caller to copy them.
// Creation remains explicit ("absent"); an unexpectedly missing edit never becomes a creation.
func GeneratePlan(ctx context.Context, options Options, spec Plan) (Plan, error) {
	plan, _, err := GeneratePlanWithRecounts(ctx, options, spec, nil)
	return plan, err
}

func GeneratePlanWithRecounts(ctx context.Context, options Options, spec Plan, targets []CountTarget) (Plan, []EditDiagnostic, error) {
	if spec.Version != 1 || len(spec.Files) == 0 || len(spec.Files) > 200 {
		return Plan{}, nil, errors.New("spec version must be 1 with 1–200 files")
	}
	selected := map[[2]int]bool{}
	selectedFiles := map[int]bool{}
	for _, target := range targets {
		if target.File < 1 || target.File > len(spec.Files) {
			return Plan{}, nil, errors.New("recount file index is outside the spec")
		}
		edit := spec.Files[target.File-1]
		if target.Replacement < 1 || target.Replacement > len(edit.Replacements) || edit.SHA256 == "absent" || edit.Content != nil {
			return Plan{}, nil, editError(edit.Path, fmt.Errorf("recount replacement %d must select an existing-file replacement", target.Replacement))
		}
		key := [2]int{target.File - 1, target.Replacement - 1}
		if selected[key] {
			return Plan{}, nil, editError(edit.Path, errors.New("duplicate recount target"))
		}
		selected[key] = true
		selectedFiles[target.File-1] = true
	}
	s, err := openScope(options)
	if err != nil {
		return Plan{}, nil, err
	}
	defer s.root.Close()
	plan := Plan{Version: 1, Files: append([]Edit{}, spec.Files...)}
	seen := map[string]bool{}
	total := 0
	corrections := []EditDiagnostic{}
	if len(plan.Files) > s.options.MaxFiles {
		return Plan{}, nil, errors.New("spec exceeds maximum selected files")
	}
	for i := range plan.Files {
		if err := ctx.Err(); err != nil {
			return Plan{}, nil, err
		}
		edit := &plan.Files[i]
		name, err := cleanPath(edit.Path)
		if err != nil {
			return Plan{}, nil, editError(edit.Path, err)
		}
		if seen[name] {
			return Plan{}, nil, editError(name, errors.New("duplicate spec path"))
		}
		seen[name] = true
		if edit.SHA256 == "" {
			data, _, err := s.read(name)
			if err != nil {
				return Plan{}, nil, editError(name, err)
			}
			edit.SHA256 = digest(data)
			if selectedFiles[i] {
				if !validText(data) {
					return Plan{}, nil, editError(name, errors.New("recount requires UTF-8 text"))
				}
				edit.Replacements = append([]Replacement{}, edit.Replacements...)
				text := string(data)
				for j := range edit.Replacements {
					replacement := &edit.Replacements[j]
					if replacement.Old == "" || replacement.Count < 1 {
						return Plan{}, nil, editError(name, errors.New("replacement requires nonempty old and positive exact count"))
					}
					actual := strings.Count(text, replacement.Old)
					if actual != replacement.Count {
						expected := replacement.Count
						diagnostic := EditDiagnostic{Path: name, Code: "replacement_count", Replacement: j + 1, Expected: &expected, Actual: &actual, Message: "replacement count differs from plan"}
						if !selected[[2]int{i, j}] || actual == 0 {
							return Plan{}, nil, &diagnostic
						}
						corrections = append(corrections, diagnostic)
						replacement.Count = actual
					}
					text = strings.ReplaceAll(text, replacement.Old, replacement.New)
				}
			}
		} else if edit.SHA256 != "absent" {
			return Plan{}, nil, editError(name, errors.New("spec hashes must be omitted for existing files or absent for explicit creation; use --plan for expected hashes"))
		}
		item, err := s.prepare(*edit)
		if err != nil {
			return Plan{}, nil, editError(name, err)
		}
		total += len(item.data)
		if total > 32<<20 {
			return Plan{}, nil, errors.New("batch byte limit exceeded")
		}
	}
	return plan, corrections, nil
}
