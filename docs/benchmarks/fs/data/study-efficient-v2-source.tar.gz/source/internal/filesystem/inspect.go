package filesystem

import (
	"context"
	"encoding/json"
	"errors"
	"regexp"
	"sort"
	"strings"
	"unicode/utf8"
)

type InspectOptions struct {
	Options
	Patterns            []string
	Regex               bool
	Context, Start, End int
	Hash                bool
}
type Range struct {
	Start int      `json:"start"`
	Lines []string `json:"lines"`
}
type File struct {
	Path    string  `json:"path"`
	Bytes   int64   `json:"bytes"`
	SHA256  string  `json:"sha256,omitempty"`
	Matches []int   `json:"matches,omitempty"`
	Ranges  []Range `json:"ranges,omitempty"`
}
type Inspection struct {
	Status   string    `json:"status"`
	Files    []File    `json:"files"`
	Problems []Problem `json:"problems,omitempty"`
	Complete bool      `json:"complete"`
}

func textLines(data []byte) []string {
	s := strings.ReplaceAll(string(data), "\r\n", "\n")
	s = strings.TrimSuffix(s, "\n")
	if len(data) == 0 {
		return []string{}
	}
	return strings.Split(s, "\n")
}
func validText(data []byte) bool { return utf8.Valid(data) && !strings.ContainsRune(string(data), 0) }
func selectedRanges(lines []string, matches []int, context int) []Range {
	out := []Range{}
	for _, line := range matches {
		start := max(1, line-context)
		end := min(len(lines), line+context)
		if len(out) > 0 {
			last := &out[len(out)-1]
			oldEnd := last.Start + len(last.Lines) - 1
			if start <= oldEnd+1 {
				if end > oldEnd {
					last.Lines = append(last.Lines, lines[oldEnd:end]...)
				}
				continue
			}
		}
		out = append(out, Range{start, append([]string{}, lines[start-1:end]...)})
	}
	return out
}
func Inspect(ctx context.Context, options InspectOptions) (Inspection, error) {
	result := Inspection{Status: "ok", Files: []File{}, Complete: true}
	if options.Context < 0 || options.Context > 1000 || options.Start < 0 || options.End < 0 || options.End > 0 && (options.Start < 1 || options.End < options.Start) {
		return result, errors.New("invalid context or line range")
	}
	if options.Start > 0 && options.End == 0 {
		options.End = options.Start
	}
	patterns := []*regexp.Regexp{}
	for _, p := range options.Patterns {
		if p == "" {
			return result, errors.New("pattern must not be empty")
		}
		if !options.Regex {
			p = regexp.QuoteMeta(p)
		}
		rx, err := regexp.Compile(p)
		if err != nil {
			return result, err
		}
		patterns = append(patterns, rx)
	}
	s, err := openScope(options.Options)
	if err != nil {
		return result, err
	}
	defer s.root.Close()
	names, problems, err := s.files(ctx)
	if err != nil {
		return result, err
	}
	sort.Strings(names)
	result.Problems = problems
	for _, name := range names {
		if ctx.Err() != nil {
			return result, ctx.Err()
		}
		info, err := s.root.Lstat(name)
		if err != nil {
			result.Problems = append(result.Problems, Problem{name, err.Error()})
			continue
		}
		item := File{Path: name, Bytes: info.Size()}
		if len(patterns) > 0 || options.Start > 0 || options.Hash {
			data, _, err := s.read(name)
			if err != nil {
				result.Problems = append(result.Problems, Problem{name, err.Error()})
				continue
			}
			item.Bytes = int64(len(data))
			if options.Hash {
				item.SHA256 = digest(data)
			}
			if len(patterns) > 0 || options.Start > 0 {
				if !validText(data) {
					result.Problems = append(result.Problems, Problem{name, "not UTF-8 text; metadata-only inspection is available"})
					continue
				}
				lines := textLines(data)
				for i, line := range lines {
					if options.Start > 0 && (i+1 < options.Start || i+1 > options.End) {
						continue
					}
					for _, rx := range patterns {
						if rx.MatchString(line) {
							item.Matches = append(item.Matches, i+1)
							break
						}
					}
				}
				if len(patterns) > 0 {
					if len(item.Matches) == 0 {
						continue
					}
					item.Ranges = selectedRanges(lines, item.Matches, options.Context)
				} else if options.Start <= len(lines) {
					item.Ranges = []Range{{options.Start, append([]string{}, lines[options.Start-1:min(options.End, len(lines))]...)}}
				}
			}
		}
		result.Files = append(result.Files, item)
		encoded, _ := json.Marshal(result)
		if len(encoded) > s.options.MaxOutputBytes {
			result.Files = result.Files[:len(result.Files)-1]
			result.Problems = append(result.Problems, Problem{name, "output byte limit reached; remaining matches omitted"})
			break
		}
	}
	if len(result.Problems) > 0 {
		result.Status = "partial"
		result.Complete = false
	}
	return result, nil
}
