package cli

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"

	"github.com/east-true/my-agent-tools/internal/filesystem"
)

const fsHelp = `Usage:
  tools fs inspect --root DIR [--include GLOB] [--pattern TEXT] [--path FILE] [--range START:END] [--hash] [--json]
  tools fs delta --root DIR --state-file FILE [--include GLOB] [--include-content] [--json]
  tools fs apply --root DIR --plan FILE [--apply] [--json]

inspect combines file selection, multiple literal searches and bounded line ranges.
delta records content hashes; repeat the same state file for added/modified/deleted files.
apply validates every preimage and exact replacement count before writing. Default: preview.
Patterns/paths/include/exclude flags may repeat; ** matches directory components.
Generated state/build directories and symlinks are skipped. No Git or authentication needed.
Use 'tools fs <command> --help' for options.
`

type fsStrings []string

func (values *fsStrings) String() string { return strings.Join(*values, ",") }
func (values *fsStrings) Set(value string) error {
	if value == "" {
		return errors.New("empty value")
	}
	*values = append(*values, value)
	return nil
}

func runFilesystem(ctx context.Context, args []string, in io.Reader, out, stderr io.Writer) int {
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" {
		fmt.Fprint(out, fsHelp)
		return 0
	}
	action := args[0]
	if action != "inspect" && action != "delta" && action != "apply" {
		fmt.Fprintf(stderr, "unknown fs command %q\n", action)
		return 2
	}
	flags := flag.NewFlagSet("tools fs "+action, flag.ContinueOnError)
	flags.SetOutput(stderr)
	options := filesystem.Options{}
	flags.StringVar(&options.Root, "root", ".", "directory tree to access")
	flags.IntVar(&options.MaxFiles, "max-files", 200, "maximum selected files (partial results do not advance state)")
	flags.Int64Var(&options.MaxFileBytes, "max-file-bytes", 1<<20, "maximum bytes per file")
	flags.IntVar(&options.MaxOutputBytes, "max-output-bytes", 64<<10, "maximum inspect/delta result bytes")
	jsonOutput := flags.Bool("json", false, "emit structured JSON")
	var include, exclude, paths, patterns fsStrings
	var hash, regex, content, reset, execute bool
	var lineRange, stateFile, planFile string
	contextLines := 0
	if action != "apply" {
		flags.Var(&include, "include", "include glob; repeatable (default all regular files)")
		flags.Var(&exclude, "exclude", "exclude glob; repeatable")
		flags.Var(&paths, "path", "select one root-relative file; repeatable")
	}
	if action == "inspect" {
		flags.Var(&patterns, "pattern", "literal pattern; repeatable")
		flags.BoolVar(&regex, "regex", false, "patterns are Go regular expressions")
		flags.BoolVar(&hash, "hash", false, "include original-byte SHA-256")
		flags.StringVar(&lineRange, "range", "", "1-based inclusive START:END range")
	}
	if action == "delta" {
		flags.StringVar(&stateFile, "state-file", "", "baseline snapshot file (required)")
		flags.BoolVar(&content, "include-content", false, "include changed text ranges and store baseline text")
		flags.BoolVar(&reset, "reset", false, "replace a valid same-root baseline for a new selection")
	}
	if action != "apply" {
		flags.IntVar(&contextLines, "context", 0, "lines around matches or changed spans")
	}
	if action == "apply" {
		flags.StringVar(&planFile, "plan", "", "version 1 JSON edit plan, or - for stdin")
		flags.BoolVar(&execute, "apply", false, "apply the fully validated plan (default preview)")
	}
	flags.Usage = func() { fmt.Fprintf(stderr, "Usage: tools fs %s [options]\n", action); flags.PrintDefaults() }
	if err := flags.Parse(args[1:]); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return 0
		}
		return 2
	}
	failure := func(err error) int {
		if *jsonOutput {
			encode(out, stderr, map[string]any{"status": "error", "error": err.Error()})
		} else {
			fmt.Fprintln(stderr, "error:", err)
		}
		return 1
	}
	if flags.NArg() > 0 {
		return failure(errors.New("unexpected positional arguments"))
	}
	options.Include, options.Exclude, options.Paths = include, exclude, paths
	var result any
	var err error
	complete := true
	switch action {
	case "inspect":
		opts := filesystem.InspectOptions{Options: options, Patterns: patterns, Regex: regex, Context: contextLines, Hash: hash}
		if lineRange != "" {
			parts := strings.Split(lineRange, ":")
			if len(parts) != 2 {
				return failure(errors.New("range must be START:END"))
			}
			opts.Start, err = strconv.Atoi(parts[0])
			if err != nil {
				return failure(err)
			}
			opts.End, err = strconv.Atoi(parts[1])
			if err != nil {
				return failure(err)
			}
			if opts.Start < 1 || opts.End < opts.Start {
				return failure(errors.New("range must be positive and ordered"))
			}
		}
		value, e := filesystem.Inspect(ctx, opts)
		result, err, complete = value, e, value.Complete
	case "delta":
		value, e := filesystem.Delta(ctx, filesystem.DeltaOptions{Options: options, StateFile: stateFile, Content: content, Context: contextLines, Reset: reset})
		result, err, complete = value, e, value.Complete
	case "apply":
		if planFile == "" {
			return failure(errors.New("--plan is required"))
		}
		reader := in
		if planFile != "-" {
			file, e := os.Open(planFile)
			if e != nil {
				return failure(e)
			}
			defer file.Close()
			reader = file
		}
		decoder := json.NewDecoder(io.LimitReader(reader, 32<<20))
		decoder.DisallowUnknownFields()
		var plan filesystem.Plan
		if e := decoder.Decode(&plan); e != nil {
			return failure(e)
		}
		var extra any
		if decoder.Decode(&extra) != io.EOF {
			return failure(errors.New("plan contains trailing JSON or exceeds size limit"))
		}
		value, e := filesystem.Apply(ctx, options, plan, execute)
		result, err, complete = value, e, value.Complete
	}
	if err != nil {
		return failure(err)
	}
	// JSON is the stable batch interface; human output uses the same result without a second interpretation.
	if encode(out, stderr, result) != 0 {
		return 1
	}
	if !complete {
		return 1
	}
	return 0
}
