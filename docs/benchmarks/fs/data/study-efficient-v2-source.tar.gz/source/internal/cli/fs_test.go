package cli

import (
	"bytes"
	"context"
	"errors"
	"github.com/east-true/my-agent-tools/internal/command"
	"github.com/east-true/my-agent-tools/internal/github"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestFilesystemDispatchNeverAuthenticatesAndReportsPartialResults(t *testing.T) {
	root := t.TempDir()
	os.WriteFile(filepath.Join(root, "a.txt"), []byte("alpha\n한국어\n"), 0600)
	for _, args := range [][]string{{"fs"}, {"fs", "inspect", "--help"}, {"fs", "inspect", "--root", root, "--pattern", "한국어", "--json"}, {"fs", "delta", "--root", root, "--state-file", filepath.Join(root, ".tools/state/s.json"), "--json"}, {"fs", "apply", "--root", root, "--plan", "-", "--json"}} {
		var out, stderr bytes.Buffer
		code := run(context.Background(), args, strings.NewReader(`{"version":1,"files":[{"path":"created.txt","sha256":"absent","content":"new\n"}]}`), &out, &stderr, fakeRunner{}, func(context.Context, command.Runner) (github.API, error) {
			t.Fatal("filesystem called GitHub authentication")
			return nil, errors.New("unavailable")
		})
		if code != 0 {
			t.Fatal(args, code, out.String(), stderr.String())
		}
	}
	var out, stderr bytes.Buffer
	code := runFilesystem(context.Background(), []string{"inspect", "--root", root, "--path", "missing.txt", "--json"}, nil, &out, &stderr)
	if code != 1 || !strings.Contains(out.String(), `"complete":false`) {
		t.Fatal(code, out.String(), stderr.String())
	}
	out.Reset()
	code = runFilesystem(context.Background(), []string{"apply", "--root", root, "--plan", "-", "--apply", "--json"}, strings.NewReader(`{"version":1,"files":[{"path":"../outside.txt","sha256":"absent","content":"new"}]}`), &out, &stderr)
	if code != 1 || !strings.Contains(out.String(), `"status":"blocked"`) {
		t.Fatal(code, out.String())
	}
}
