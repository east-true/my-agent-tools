package filesystem

import (
	"context"
	"errors"
)

// GeneratePlan captures exact original-byte hashes without asking the caller to copy them.
// Creation remains explicit ("absent"); an unexpectedly missing edit never becomes a creation.
func GeneratePlan(ctx context.Context, options Options, spec Plan) (Plan, error) {
	if spec.Version != 1 || len(spec.Files) == 0 || len(spec.Files) > 200 {
		return Plan{}, errors.New("spec version must be 1 with 1–200 files")
	}
	s, err := openScope(options)
	if err != nil {
		return Plan{}, err
	}
	defer s.root.Close()
	plan := Plan{Version: 1, Files: append([]Edit{}, spec.Files...)}
	seen := map[string]bool{}
	total := 0
	if len(plan.Files) > s.options.MaxFiles {
		return Plan{}, errors.New("spec exceeds maximum selected files")
	}
	for i := range plan.Files {
		if err := ctx.Err(); err != nil {
			return Plan{}, err
		}
		edit := &plan.Files[i]
		name, err := cleanPath(edit.Path)
		if err != nil {
			return Plan{}, editError(edit.Path, err)
		}
		if seen[name] {
			return Plan{}, editError(name, errors.New("duplicate spec path"))
		}
		seen[name] = true
		if edit.SHA256 == "" {
			data, _, err := s.read(name)
			if err != nil {
				return Plan{}, editError(name, err)
			}
			edit.SHA256 = digest(data)
		} else if edit.SHA256 != "absent" {
			return Plan{}, editError(name, errors.New("spec hashes must be omitted for existing files or absent for explicit creation; use --plan for expected hashes"))
		}
		item, err := s.prepare(*edit)
		if err != nil {
			return Plan{}, editError(name, err)
		}
		total += len(item.data)
		if total > 32<<20 {
			return Plan{}, errors.New("batch byte limit exceeded")
		}
	}
	return plan, nil
}
