package cli

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/east-true/my-agent-tools/internal/command"
	"github.com/east-true/my-agent-tools/internal/github"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestFilesystemDispatchNeverAuthenticatesAndReportsPartialResults(t *testing.T) {
	root := t.TempDir()
	os.WriteFile(filepath.Join(root, "a.txt"), []byte("alpha\n한국어\n"), 0600)
	for _, args := range [][]string{{"fs"}, {"fs", "inspect", "--help"}, {"fs", "inspect", "--root", root, "--pattern", "한국어", "--json"}, {"fs", "delta", "--root", root, "--state-file", filepath.Join(root, ".tools/state/s.json"), "--json"}, {"fs", "apply", "--root", root, "--plan", "-", "--json"}} {
		var out, stderr bytes.Buffer
		code := run(context.Background(), args, strings.NewReader(`{"version":1,"files":[{"path":"created.txt","sha256":"absent","content":"new\n"}]}`), &out, &stderr, fakeRunner{}, func(context.Context, command.Runner) (github.API, error) {
			t.Fatal("filesystem called GitHub authentication")
			return nil, errors.New("unavailable")
		})
		if code != 0 {
			t.Fatal(args, code, out.String(), stderr.String())
		}
	}
	var out, stderr bytes.Buffer
	code := runFilesystem(context.Background(), []string{"inspect", "--root", root, "--path", "missing.txt", "--json"}, nil, &out, &stderr)
	if code != 1 || !strings.Contains(out.String(), `"complete":false`) {
		t.Fatal(code, out.String(), stderr.String())
	}
	out.Reset()
	code = runFilesystem(context.Background(), []string{"apply", "--root", root, "--plan", "-", "--apply", "--json"}, strings.NewReader(`{"version":1,"files":[{"path":"../outside.txt","sha256":"absent","content":"new"}]}`), &out, &stderr)
	if code != 1 || !strings.Contains(out.String(), `"status":"blocked"`) {
		t.Fatal(code, out.String())
	}
}

func TestFilesystemSpecSavesExpectedHashesAndAppliesWithVerifiedLines(t *testing.T) {
	root := t.TempDir()
	original := []byte("limit=08\r\nkeep\r\n")
	os.WriteFile(filepath.Join(root, "a.txt"), original, 0600)
	saved := filepath.Join(root, "plan.json")
	var out, stderr bytes.Buffer
	code := runFilesystem(context.Background(), []string{"apply", "--root", root, "--spec", "-", "--save-plan", saved, "--apply", "--report-changes", "--json"}, strings.NewReader(`{"version":1,"files":[{"path":"a.txt","replacements":[{"old":"limit=08","new":"limit=64","count":1}]}]}`), &out, &stderr)
	if code != 0 || !strings.Contains(out.String(), `"verified":true`) || !strings.Contains(out.String(), `"limit=64"`) {
		t.Fatal(code, out.String(), stderr.String())
	}
	raw, _ := os.ReadFile(saved)
	var plan struct {
		Files []struct {
			SHA256 string `json:"sha256"`
		} `json:"files"`
	}
	if json.Unmarshal(raw, &plan) != nil || len(plan.Files) != 1 || plan.Files[0].SHA256 != fmt.Sprintf("%x", sha256.Sum256(original)) {
		t.Fatal(string(raw))
	}
	got, _ := os.ReadFile(filepath.Join(root, "a.txt"))
	if string(got) != "limit=64\r\nkeep\r\n" {
		t.Fatal(string(got))
	}
	// An existing saved plan is never overwritten, and no new edits run on that failure.
	out.Reset()
	code = runFilesystem(context.Background(), []string{"apply", "--root", root, "--spec", "-", "--save-plan", saved, "--apply", "--json"}, strings.NewReader(`{"version":1,"files":[{"path":"a.txt","replacements":[{"old":"limit=64","new":"limit=99","count":1}]}]}`), &out, &stderr)
	if code != 1 {
		t.Fatal(code, out.String())
	}
	got, _ = os.ReadFile(filepath.Join(root, "a.txt"))
	if !bytes.Equal(got, []byte("limit=64\r\nkeep\r\n")) {
		t.Fatal("edited after plan save failure")
	}
}
