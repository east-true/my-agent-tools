package cli

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/east-true/my-agent-tools/internal/filesystem"
)

const fsHelp = `Usage:
  tools fs inspect --root DIR [--include GLOB] [--pattern TEXT] [--path FILE] [--range START:END] [--hash] [--json]
  tools fs delta --root DIR --state-file FILE [--include GLOB] [--include-content] [--json]
  tools fs apply --root DIR --plan FILE [--apply] [--json]

inspect combines file selection, multiple literal searches and bounded line ranges.
delta records content hashes; repeat the same state file for added/modified/deleted files.
apply validates every preimage and exact replacement count before writing. Default: preview.
Patterns/paths/include/exclude flags may repeat; ** matches directory components.
Generated state/build directories and symlinks are skipped. No Git or authentication needed.
Use 'tools fs <command> --help' for options.
`

type fsStrings []string

func (values *fsStrings) String() string { return strings.Join(*values, ",") }
func (values *fsStrings) Set(value string) error {
	if value == "" {
		return errors.New("empty value")
	}
	*values = append(*values, value)
	return nil
}

func runFilesystem(ctx context.Context, args []string, in io.Reader, out, stderr io.Writer) int {
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" {
		fmt.Fprint(out, fsHelp)
		return 0
	}
	action := args[0]
	if action != "inspect" && action != "delta" && action != "apply" {
		fmt.Fprintf(stderr, "unknown fs command %q\n", action)
		return 2
	}
	flags := flag.NewFlagSet("tools fs "+action, flag.ContinueOnError)
	flags.SetOutput(stderr)
	options := filesystem.Options{}
	flags.StringVar(&options.Root, "root", ".", "directory tree to access")
	flags.IntVar(&options.MaxFiles, "max-files", 200, "maximum selected files (partial results do not advance state)")
	flags.Int64Var(&options.MaxFileBytes, "max-file-bytes", 1<<20, "maximum bytes per file")
	flags.IntVar(&options.MaxOutputBytes, "max-output-bytes", 64<<10, "maximum inspect/delta result bytes")
	jsonOutput := flags.Bool("json", false, "emit structured JSON")
	var include, exclude, paths, patterns, contentKinds fsStrings
	var hash, regex, content, reset, execute, peek, reportChanges bool
	var lineRange, stateFile, planFile, specFile, savePlan, requestFile, cursor string
	contextLines := 0
	if action != "apply" {
		flags.Var(&include, "include", "include glob; repeatable (default all regular files)")
		flags.Var(&exclude, "exclude", "exclude glob; repeatable")
		flags.Var(&paths, "path", "select one root-relative file; repeatable")
	}
	if action == "inspect" {
		flags.Var(&patterns, "pattern", "literal pattern; repeatable")
		flags.BoolVar(&regex, "regex", false, "patterns are Go regular expressions")
		flags.BoolVar(&hash, "hash", false, "include original-byte SHA-256")
		flags.StringVar(&lineRange, "range", "", "1-based inclusive START:END range")
		flags.StringVar(&requestFile, "request", "", "version 1 JSON with file-specific ranges/patterns, or - for stdin")
		flags.StringVar(&cursor, "cursor", "", "continue an unchanged query using next_cursor")
	}
	if action == "delta" {
		flags.StringVar(&stateFile, "state-file", "", "baseline snapshot file (required)")
		flags.BoolVar(&content, "include-content", false, "include changed text ranges and store baseline text")
		flags.BoolVar(&reset, "reset", false, "replace a valid same-root baseline for a new selection")
		flags.BoolVar(&peek, "peek", false, "compare without advancing an existing baseline")
		flags.Var(&contentKinds, "content-kinds", "include text only for this change kind; added/modified/deleted, repeatable")
	}
	if action != "apply" {
		flags.IntVar(&contextLines, "context", 0, "lines around matches or changed spans")
	}
	if action == "apply" {
		flags.StringVar(&planFile, "plan", "", "version 1 JSON edit plan, or - for stdin")
		flags.BoolVar(&execute, "apply", false, "apply the fully validated plan (default preview)")
		flags.StringVar(&specFile, "spec", "", "hashless version 1 edit spec; create hashes internally, or - for stdin")
		flags.StringVar(&savePlan, "save-plan", "", "save a generated validated plan without overwriting an existing file")
		flags.BoolVar(&reportChanges, "report-changes", false, "include changed lines; applied files are always read back and verified")
	}
	flags.Usage = func() { fmt.Fprintf(stderr, "Usage: tools fs %s [options]\n", action); flags.PrintDefaults() }
	if err := flags.Parse(args[1:]); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return 0
		}
		return 2
	}
	failure := func(err error) int {
		if *jsonOutput {
			encode(out, stderr, map[string]any{"status": "error", "error": err.Error()})
		} else {
			fmt.Fprintln(stderr, "error:", err)
		}
		return 1
	}
	if flags.NArg() > 0 {
		return failure(errors.New("unexpected positional arguments"))
	}
	options.Include, options.Exclude, options.Paths = include, exclude, paths
	var result any
	var err error
	complete := true
	switch action {
	case "inspect":
		opts := filesystem.InspectOptions{Options: options, Patterns: patterns, Regex: regex, Context: contextLines, Hash: hash}
		opts.Cursor = cursor
		if requestFile != "" {
			var batch filesystem.ReadBatch
			if e := readFSJSON(requestFile, in, &batch); e != nil {
				return failure(e)
			}
			if batch.Version != 1 || len(batch.Files) == 0 {
				return failure(errors.New("request version must be 1 with nonempty files"))
			}
			opts.Requests = batch.Files
		}
		if lineRange != "" {
			parts := strings.Split(lineRange, ":")
			if len(parts) != 2 {
				return failure(errors.New("range must be START:END"))
			}
			opts.Start, err = strconv.Atoi(parts[0])
			if err != nil {
				return failure(err)
			}
			opts.End, err = strconv.Atoi(parts[1])
			if err != nil {
				return failure(err)
			}
			if opts.Start < 1 || opts.End < opts.Start {
				return failure(errors.New("range must be positive and ordered"))
			}
		}
		value, e := filesystem.Inspect(ctx, opts)
		result, err, complete = value, e, value.Complete || value.Status == "page"
	case "delta":
		value, e := filesystem.Delta(ctx, filesystem.DeltaOptions{Options: options, StateFile: stateFile, Content: content, Context: contextLines, Reset: reset, Peek: peek, ContentKinds: contentKinds})
		result, err, complete = value, e, value.Complete
	case "apply":
		if (planFile == "") == (specFile == "") {
			return failure(errors.New("choose exactly one of --plan or --spec"))
		}
		if savePlan != "" && specFile == "" {
			return failure(errors.New("--save-plan requires --spec"))
		}
		var plan filesystem.Plan
		input := planFile
		if specFile != "" {
			input = specFile
		}
		if e := readFSJSON(input, in, &plan); e != nil {
			return failure(e)
		}
		if specFile != "" {
			plan, err = filesystem.GeneratePlan(ctx, options, plan)
			if err != nil {
				return failure(err)
			}
			if savePlan != "" {
				root, e := filepath.Abs(options.Root)
				if e != nil {
					return failure(e)
				}
				root, e = filepath.EvalSymlinks(root)
				if e != nil {
					return failure(e)
				}
				destination, e := filepath.Abs(savePlan)
				if e != nil {
					return failure(e)
				}
				parent, e := filepath.EvalSymlinks(filepath.Dir(destination))
				if e != nil {
					return failure(e)
				}
				destination = filepath.Join(parent, filepath.Base(destination))
				for _, edit := range plan.Files {
					if strings.EqualFold(destination, filepath.Join(root, filepath.FromSlash(edit.Path))) {
						return failure(errors.New("saved plan cannot be an edit destination"))
					}
				}
				file, e := os.OpenFile(destination, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
				if e != nil {
					return failure(e)
				}
				e = json.NewEncoder(file).Encode(plan)
				if e == nil {
					e = file.Sync()
				}
				closeErr := file.Close()
				if e == nil {
					e = closeErr
				}
				if e != nil {
					os.Remove(destination)
					return failure(e)
				}
			}
		}
		value, e := filesystem.ApplyWithReport(ctx, options, plan, execute, reportChanges)
		value.PlanFile = savePlan
		result, err, complete = value, e, value.Complete
	}
	if err != nil {
		return failure(err)
	}
	// JSON is the stable batch interface; human output uses the same result without a second interpretation.
	if encode(out, stderr, result) != 0 {
		return 1
	}
	if !complete {
		return 1
	}
	return 0
}

func readFSJSON(name string, in io.Reader, value any) error {
	reader := in
	if name != "-" {
		file, err := os.Open(name)
		if err != nil {
			return err
		}
		defer file.Close()
		reader = file
	}
	decoder := json.NewDecoder(io.LimitReader(reader, 32<<20))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(value); err != nil {
		return err
	}
	var extra any
	if decoder.Decode(&extra) != io.EOF {
		return errors.New("input contains trailing JSON or exceeds size limit")
	}
	return nil
}
