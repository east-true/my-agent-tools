#!/usr/bin/env python3
"""Publish only a complete, audited repeated study and refresh both READMEs."""
import argparse
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

from run_github_study import TASKS, REPETITIONS, summarize, validate_frozen
from publish_all_github_benchmark import NAMES


def archive(path,entries):
    with path.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as tar:
                for name,data in sorted(entries):
                    item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
                    tar.addfile(item,io.BytesIO(data))


def table(report,base,korean):
    lines=['| 명령 | 직접 처리 평균 | `tools` 평균 | 변화 | 정답·상태 |' if korean else
           '| Command | Direct mean | `tools` mean | Change | Answer + state |','|---|---:|---:|---:|---:|']
    for task in TASKS:
        s=report['summary'][task];gh,to=s['gh'],s['tools']
        key='uncached_plus_output'
        change=f"{s['change_percent'][key]:+.1f}%".replace('-','−') if s['comparison_eligible'] else ('비교 보류' if korean else 'Withheld')
        lines.append(f"| [`github {NAMES[task]}`]({base}repeated.md) | {gh['metrics'][key]['mean']:,.0f} | {to['metrics'][key]['mean']:,.0f} | {change} | {gh['correct']+to['correct']}/6 |")
    return lines


def total_table(report,korean):
    lines=['| 명령 | 직접 총 토큰 평균 | tools 총 토큰 평균 | 총 토큰 변화 |' if korean else
           '| Command | Direct total mean | tools total mean | Total change |','|---|---:|---:|---:|']
    for task in TASKS:
        s=report['summary'][task];gh,to=s['gh'],s['tools'];key='input_plus_output'
        change=f"{s['change_percent'][key]:+.1f}%".replace('-','−') if s['comparison_eligible'] else ('비교 보류' if korean else 'Withheld')
        lines.append(f"| `github {NAMES[task]}` | {gh['metrics'][key]['mean']:,.0f} | {to['metrics'][key]['mean']:,.0f} | {change} |")
    return lines


def refresh_readmes(repo,report):
    correct=sum(r['correct'] for r in report['trials']);state=sum(r['state_correct'] for r in report['trials'])
    settings=report['protocol']['configured_defaults'];model,effort=settings['model'],settings['model_reasoning_effort']
    for relative,korean in [('README.md',False),('docs/README.ko.md',True)]:
        path=repo/relative;base='benchmarks/github/' if korean else 'docs/benchmarks/github/'
        title='## 토큰 사용량 실측' if korean else '## Token usage measurements'
        end='## 설치' if korean else '## Install'
        lines=[title,'']
        if korean:
            lines += [f'GitHub 명령 **15개 전체**를 직접 `gh`/Git과 `tools`로 **방식별 새 세션 3회씩, 총 90회** 비교했습니다. 사용자 기본 모델·추론 설정을 상속했으며 당시 설정 값은 `{model}` / `{effort}`였습니다. 명령 순서를 섞고 각 쌍의 실행 순서를 교차했습니다.','',
                      '표는 **캐시 제외 입력 + 출력 토큰의 평균**입니다. 캐시 입력을 포함한 총 토큰·각 실행의 범위·성공률은 원본 보고서에 따로 공개합니다.','']
        else:
            lines += [f'All **15 GitHub commands** were compared with direct `gh`/Git in **three fresh sessions per method, 90 runs total**. User model and reasoning defaults were inherited; the recorded configuration was `{model}` / `{effort}`. Task order was shuffled and method order alternated within pairs.','',
                      'The table reports **mean uncached input + output tokens**. The report also provides totals including cached input, per-run ranges, and correctness rates.','']
        lines+=table(report,base,korean)+['']
        lines+=['캐시 입력까지 포함한 총 토큰도 함께 비교합니다.' if korean else 'Totals including cached input are also shown for comparison.','']
        lines+=total_table(report,korean)+['']
        if korean:
            lines += [f'실제 상태 검증은 **{state}/90**, 정답 JSON과 상태를 모두 만족한 실행은 **{correct}/90**입니다. 실패·재시도도 비용에 포함했고 실패한 모델 실행을 교체하지 않았습니다. 어느 방식이든 3회 전부 통과하지 않은 명령은 변화율 비교를 보류합니다.','',
                      '이 결과는 공개한 **고정 실험 작업**의 에이전트 토큰 비교입니다. 실제 CLI·`gh`·Git을 사용하고 GitHub API는 선택 필드·별칭을 처리하는 로컬 GraphQL 서버와 임시 저장소로 재현했습니다. 캐시를 강제로 초기화하지 못해 실행 순서를 교차했습니다. 캐시 제외 집계에도 캐시 적중 차이의 영향이 남으므로 총 토큰·범위를 함께 확인해야 하며, 요금 절감이나 모든 프로젝트의 절감률을 뜻하지 않습니다. CLI 자체는 모델을 호출하지 않습니다.','',
                      f'[측정 계획·작업 범위·평균/범위·전체 원본·재현]({base}repeated.md). [이전 1회 예비 측정]({base}all-defaults.md)과 [기존 모델 비교]({base}models.md)는 별도 조건으로 보존합니다.','']
        else:
            lines += [f'Actual state checks passed in **{state}/90** runs; **{correct}/90** matched both expected JSON and state. Failures and retries remain in the cost data; failed model runs were not replaced. Changes are withheld unless all three runs of both methods pass.','',
                      'These results compare agent tokens for the published **fixed experimental workload**. Real CLI, `gh`, and Git operations use disposable repositories and a local GraphQL server with field selection and aliases. Backend cache could not be forcibly reset; method order alternated. Cache hit differences still affect uncached metrics, so totals and ranges must be considered together. This is not a monetary savings estimate or a general rate for every project. The CLI itself makes no model calls.','',
                      f'[Protocol, workload, means/ranges, complete evidence, and reproduction]({base}repeated.md). The [earlier single-run pilot]({base}all-defaults.md) and [historical model comparison]({base}models.md) retain separate conditions.','']
        content=path.read_text();start=content.index(title);stop=content.index(end,start)
        path.write_text(content[:start]+'\n'.join(lines)+'\n'+content[stop:])


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args();root=args.root.resolve();repo=Path(__file__).resolve().parents[2]
    report=json.loads((root/'report.json').read_text());protocol=report['protocol'];trials=report['trials']
    assert protocol['tasks']==TASKS and protocol['repetitions_per_method']==REPETITIONS
    assert len(trials)==90 and len({(r['task'],r['method'],r['repetition']) for r in trials})==90
    validate_frozen(root,protocol)
    assert report['summary']==summarize(trials)
    for record in trials:
        directory=root/'runs'/record['task']/f"{record['index']:02d}-{record['method']}"
        raw=(directory/'events.jsonl').read_bytes();assert hashlib.sha256(raw).hexdigest()==record['events_sha256']
        events=[json.loads(line) for line in raw.splitlines()]
        assert [e['usage'] for e in events if e['type']=='turn.completed']==[record['usage']]
        assert record['uncached_plus_output']==record['usage']['input_tokens']-record['usage']['cached_input_tokens']+record['usage']['output_tokens']
        assert record['actual']==json.loads((directory/'answer.json').read_text())
        assert '--model' not in record['execution_args'] and '--ignore-user-config' not in record['execution_args']
        assert not any('model_reasoning_effort=' in arg for arg in record['execution_args'])
    out=repo/'docs/benchmarks/github'
    source=[('source/'+name,(root/'source'/name).read_bytes()) for name in protocol['source_hashes']]
    source += [('scripts/benchmarks/'+name,(root/'harness'/name).read_bytes()) for name in protocol['runner_hashes']]
    source.append(('scripts/benchmarks/publish_github_study.py',Path(__file__).read_bytes()))
    archive(out/'repeated-source.tar.gz',source)
    allowed={'prompt.txt','schema.json','answer.json','events.jsonl','api-access.json','interface-access.jsonl','state-verification.json','native.json'}
    evidence=[(str(path.relative_to(root)),path.read_bytes()) for folder in ('runs','preflight') for path in (root/folder).rglob('*') if path.is_file() and path.name in allowed]
    evidence += [(name,(root/name).read_bytes()) for name in ('protocol.json','preflight.json','environment.json')]
    archive(out/'repeated-events.tar.gz',evidence)
    report['evidence']={'sha256':{name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ('repeated-source.tar.gz','repeated-events.tar.gz')},
        'environment':json.loads((root/'environment.json').read_text()),
        'total_input_plus_output':sum(r['input_plus_output'] for r in trials),'total_uncached_plus_output':sum(r['uncached_plus_output'] for r in trials),
        'failure_diagnostics':[{'task':r['task'],'method':r['method'],'repetition':r['repetition'],'answer_correct':r['answer_correct'],'state_correct':r['state_correct'],'actual':r['actual'],'state_checks':r['state_checks']} for r in trials if not r['correct']]}
    (out/'repeated.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    correct=sum(r['correct'] for r in trials);state=sum(r['state_correct'] for r in trials)
    lines=['# GitHub 전체 명령: 반복 비교 실험','',
        f'15개 명령 × 2개 방식 × 3회 = **90회**입니다. 실제 상태 검증은 {state}/90, 정답 JSON과 상태 검증은 {correct}/90입니다. 모델·추론 설정은 사용자 기본값을 상속했습니다. 측정 시작(UTC): `{protocol["measured_at_utc"]}`.','',
        '## 미리 고정한 측정 계획','',
        '- 동일한 Go 소스와 CLI를 한 번 빌드하고, 실행기·프롬프트·출력 스키마·기준 답·무작위 seed·90개 순서를 모델 호출 전에 고정했습니다. 재개 시 소스·실행기·CLI 해시와 사용자 기본 설정을 검증합니다.',
        '- seed 20261008로 각 반복의 명령 순서를 섞었습니다. 각 명령에서 직접 처리→tools와 tools→직접 처리를 교차하고 매번 새 세션·임시 저장소·캐시 디렉터리로 시작했습니다. OpenAI 측 프롬프트 캐시는 강제로 초기화하지 못했습니다.',
        '- 주 지표는 캐시 제외 입력+출력입니다. 보조 지표는 캐시 입력 포함 총 토큰입니다. `turn.completed.usage`에서 계산하며 추론 출력을 중복 합산하지 않습니다. 어느 지표도 요금으로 환산하지 않습니다.',
        '- 모델 실패와 재시도는 모두 포함하고 정답을 얻을 때까지 반복하지 않습니다. 데이터가 누락되거나 실험 서버 결함이 확인되면 다음 모델 호출을 중단합니다. 어느 방식이든 3회 전부 정답·상태를 만족하지 않으면 절감률 비교를 보류합니다.',
        '- 직접 처리에도 배치·jq·로컬 스크립트를 허용합니다. 사전 작성한 직접 처리 자동화는 제공하지 않으며, 제공된 사용 안내에 따라 필요한 스크립트를 만드는 비용도 측정합니다. 비교는 이 안내·작업 범위에 한정됩니다.',
        '', '## 캐시 제외 입력+출력 평균','']+table(report,'',True)+['',
        '## 총 토큰 평균과 범위','',
        '| 명령 | 직접 총 평균 [최소–최대] | tools 총 평균 [최소–최대] | 직접 캐시 제외 범위 | tools 캐시 제외 범위 |',
        '|---|---:|---:|---:|---:|']
    for task in TASKS:
        s=report['summary'][task];metrics=[s[method]['metrics'] for method in ('gh','tools')]
        totals=[m['input_plus_output'] for m in metrics];uncached=[m['uncached_plus_output'] for m in metrics]
        fmt=lambda m:f"{m['mean']:,.0f} [{m['min']:,}–{m['max']:,}]"
        lines.append(f"| `{NAMES[task]}` | {fmt(totals[0])} | {fmt(totals[1])} | {uncached[0]['min']:,}–{uncached[0]['max']:,} | {uncached[1]['min']:,}–{uncached[1]['max']:,} |")
    lines += ['','JSON에는 중앙값·표본 표준편차·각 쌍의 변화율·API 수·명령 수·소요 시간도 저장합니다. 3회는 적은 표본이므로 모집단의 신뢰구간이나 실운영 평균을 주장하지 않습니다. 캐시 제외 입력도 캐시 적중률의 영향을 받으며 캐시 통제를 대체하지 않습니다.','',
        '## 작업과 검증','',
        '각 명령의 대표 작업은 [15개 명령의 작업 범위](all-defaults.md#수행-범위와-검증)와 같습니다. 이슈 브랜치 생성·재사용과 주 워크트리 보존, PR 제출의 실제 임시 원격 push, 비동기 머지 성공 후 해당 브랜치·깨끗한 별도 워크트리 제거, 새 CI attempt의 완료, Dependabot 2페이지·null 패치를 실제 상태로도 검증합니다. 모든 옵션·오류 경로·대규모 자료를 망라한 실험은 아닙니다.','',
        '모델 없는 사전 검증에서 15개 명령의 실제 CLI 출력·상태와, 실제 gh의 익명 축소 쿼리·별칭·combined status 응답을 확인했습니다. GraphQL-core의 [스키마 실행](https://graphql-core-3.readthedocs.io/en/stable/usage/sdl.html)을 사용해 쿼리 문자열만 검사하고 불필요한 필드까지 반환하던 서버를 교체했습니다. 빈 combined status는 [GitHub 공식 명세](https://docs.github.com/en/rest/commits/statuses#get-the-combined-status-for-a-specific-reference)에 따라 pending·건수 0으로 반환합니다.','',
        '공개한 합성 자료의 제어 실험입니다. 실제 GitHub 서비스의 성능·모든 쿼리 호환성·모든 프로젝트의 절감률을 나타내지 않습니다. API는 로컬이고 Git은 임시 bare 저장소이며 실제 GitHub에 테스트 이슈·PR을 게시하지 않았습니다.','',
        '## 실패 기록','']
    failures=report['evidence']['failure_diagnostics']
    if not failures:lines.append('90회 모두 정답·상태 검증에 통과했습니다. 모델 실행의 제외·교체는 없습니다.')
    for f in failures:lines.append(f"- `{NAMES[f['task']]}` / `{f['method']}` / 반복 {f['repetition']}: 정답 {f['answer_correct']}, 상태 {f['state_correct']}. 실제 값과 실패 항목은 JSON에 저장했습니다.")
    lines += ['','## 재현과 자료','',
        '[전체 원본 JSON](repeated.json) · [90회 이벤트·답변·API·사전 검증](repeated-events.tar.gz) · [고정 소스·실행기·의존성](repeated-source.tar.gz). 원본에서 압축 파일·소스·CLI·실행기·이벤트의 SHA-256을 확인할 수 있습니다. 이전 1회 실험을 새로운 평균에 섞지 않았습니다.','',
        '```sh','python3 -m pip install --require-hashes -r scripts/benchmarks/requirements.txt',
        'python3 scripts/benchmarks/run_github_study.py --root /tmp/github-repeated',
        '# 사전 검증 후 같은 기록에서 90회 모델 실행',
        'python3 /tmp/github-repeated/harness/run_github_study.py --root /tmp/github-repeated --resume --run-models',
        'python3 scripts/benchmarks/publish_github_study.py --root /tmp/github-repeated','```','',
        '고정 소스를 재현하려면 새 디렉터리에 repeated-source.tar.gz를 풀고, 동봉 scripts 디렉터리를 source/scripts로 복사한 뒤 그 안의 run_github_study.py를 실행합니다. 해당 source가 빌드 입력으로 사용됩니다. 고정 소스는 CLI·작업 재현용이며 모델 답변이나 토큰 수의 동일성을 보장하지 않습니다.','',
        '재실행은 현재 사용자 기본 모델·추론 설정을 상속합니다. JSON 이벤트에 실제 모델·추론 강도가 나타나지 않아 설정 스냅샷과 옵션 생략으로 기록했습니다. 실행 환경의 도구 버전은 JSON의 evidence.environment에 저장했습니다.','']
    (out/'repeated.md').write_text('\n'.join(lines))
    refresh_readmes(repo,report)
    print(json.dumps({'calls':90,'correct':correct,'state_correct':state,'report':str(out/'repeated.md')},ensure_ascii=False))


if __name__=='__main__':main()
