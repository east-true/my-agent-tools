import json
import tempfile
import unittest
from importlib.util import find_spec
from pathlib import Path


@unittest.skipUnless(find_spec('graphql'), 'optional pinned GraphQL benchmark dependency unavailable')
class PublishedStudyContract(unittest.TestCase):
    def setUp(self):
        import run_github_study as study
        self.study=study
        self.directory=tempfile.TemporaryDirectory()
        self.root=Path(self.directory.name)
        self.server=study.core.Backend(self.root)
        study.setup(self.root,self.server,'pr-merge')

    def tearDown(self):
        self.server.server_close()
        self.directory.cleanup()

    def test_small_alias_and_fragment_queries_are_valid_and_project_fields(self):
        graph=self.server.graphql
        self.server.merged=True
        self.assertEqual(graph.execute({'query':'{repository(owner:"fixture",name:"command-benchmark"){pullRequest(number:7){done:merged}}}'}),
                         {'data':{'repository':{'pullRequest':{'done':True}}}})
        result=graph.execute({'query':'query Minimal($n:Int!){repository(owner:"fixture",name:"command-benchmark"){pullRequest(number:$n){...Identity}}} fragment Identity on PullRequest{sha:headRefOid}',
                              'variables':{'n':7}})
        self.assertEqual(result,{'data':{'repository':{'pullRequest':{'sha':self.server.head}}}})
        invalid=graph.execute({'query':'{repository(owner:"fixture",name:"command-benchmark"){pullRequest(number:7){notARealField}}}'})
        self.assertTrue(invalid['errors'])

    def test_complete_schedule_crosses_pair_order_and_has_no_duplicate_slots(self):
        steps=self.study.schedule()
        self.assertEqual(len(steps),90)
        self.assertEqual(len({tuple(step.items()) for step in steps}),90)
        for task in self.study.TASKS:
            orders=[]
            for repetition in (1,2,3):
                pair=[step['method'] for step in steps if step['task']==task and step['repetition']==repetition]
                self.assertEqual(set(pair),{'gh','tools'})
                orders.append(pair)
            self.assertNotEqual(orders[0],orders[1])
            self.assertEqual(orders[0],orders[2])

    def test_selected_schedule_keeps_pairs_and_excludes_other_commands(self):
        selected=['pr-reviews','pr-inspect']
        steps=self.study.schedule(selected)
        self.assertEqual(steps,[step for step in self.study.schedule() if step['task'] in selected])
        self.assertEqual(len(steps),12)
        self.assertEqual({step['task'] for step in steps},set(selected))
        for task in selected:
            for method in ('gh','tools'):
                self.assertEqual(sorted(step['repetition'] for step in steps if step['task']==task and step['method']==method),[1,2,3])
        self.assertEqual(set(self.study.summarize([],selected)),set(selected))

    def test_failures_are_included_in_metrics_but_prevent_savings_claim(self):
        rows=[]
        for repetition in (1,2,3):
            for method,value in [('gh',100),('tools',50)]:
                rows.append({'task':'context','method':method,'repetition':repetition,'usage':{},'correct':not(method=='gh' and repetition==2),
                             'state_correct':True,**{key:value for key in ('input_plus_output','uncached_plus_output','uncached_input',
                             'cached_input','output_tokens','api_calls','command_calls','seconds')}})
        summary=self.study.summarize(rows)['context']
        self.assertEqual(summary['gh']['metrics']['input_plus_output']['mean'],100)
        self.assertEqual(summary['gh']['n'],3)
        self.assertFalse(summary['comparison_eligible'])
        self.assertNotIn('change_percent',summary)


if __name__=='__main__':unittest.main()
